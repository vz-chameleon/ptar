/*
 * display.c
 *
 *  Created on: Oct 24, 2016
 *      Authors: Timothy Garwood and Valentina Zelaya
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "ptar.h"

void displayFileNames(int fd,struct header file_header){
  int size = 0;
  int lecture = read(fd,&file_header,512);
  size = octalToDecimal(file_header.File_size_in_bytes_octalB);
  
  while(lecture != 0){
    size = octalToDecimal(file_header.File_size_in_bytes_octalB);
    if(size!=0)
      lseek(fd,(size/512+1)*512,SEEK_CUR);
    lecture = read(fd,&file_header,512);
    if(strlen(file_header.File_name)!=0)
      printf("%s\n",file_header.File_name);
	
}

}


